package com.test.web.repository;

public class SpringDAO {

	public int getCount() {
		
		return 100;
	}
}
