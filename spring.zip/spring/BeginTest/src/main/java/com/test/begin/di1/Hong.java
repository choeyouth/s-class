package com.test.begin.di1;

public class Hong {

	public void coding() {

		System.out.println("코드를 작성합니다.");
		
	}
}
