package com.test.begin.di3;

public class Hong {

	 public void coding() {
		 System.out.println("코드를 작성합니다.");
	 }
}
