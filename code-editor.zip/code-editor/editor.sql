select * from tabs;

drop table voiceChannelSetting;
drop table  voiceChannel;
drop table  memberServer;
drop table  textContent;
drop table  textChannel;
drop table  serverList;
drop table  basicFile;
drop table  versionFile;
drop table  fileType;
drop table  versionInfo;
drop table  template;
drop table  basicTemplate;
drop table  styleSetting;
drop table  styleType;
drop table  theme;
drop table  chatbot;
drop table  calendar;
drop table  teamProject;
drop table  memberTeam;
drop table  project;
drop table  team;
drop table  member;
 SELECT * FROM member WHERE TABLE_NAME = "seq";
--
drop sequence seqMember;
drop sequence seqTeam;
drop sequence seqProject;
drop sequence seqMemberTeam;
drop sequence seqTeamProject;
drop sequence seqCalendar;
drop sequence seqChatbot;
drop sequence seqTheme;
drop sequence seqStyleType;
drop sequence seqStyleSetting;
drop sequence seqBasicTemplate;
drop sequence seqTemplate;
drop sequence seqVersionInfo;
drop sequence seqFileType;
drop sequence seqVersionFile;
drop sequence seqBasicFile;
drop sequence seqServerList;
drop sequence seqTextChannel;
drop sequence seqTextContent;
drop sequence seqMemberServer;
drop sequence seqVoiceChannel;
drop sequence seqVoiceChannelSetting;


create sequence seqMember;
-- drop sequence seqMember;
CREATE TABLE member (
	seq	number	primary key,
	id	varchar2(150) unique	NOT NULL,
	pw	varchar2(100)	NOT NULL,
	nick	varchar2(100) unique	NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	ing	number	DEFAULT 1	NOT NULL,
	color	number	DEFAULT 1	NOT NULL,
	oAuthType	number	DEFAULT 1	NOT NULL
);

create sequence seqTeam;
-- drop sequence seqTeam;
CREATE TABLE team (
	seq	number	primary key,
	teamName	varchar2(50)	NOT NULL,
	teamEx	varchar2(1000)	NULL,
	teamType	number	DEFAULT 2	NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL
);

create sequence seqProject;
-- drop sequence seqProject;
CREATE TABLE project (
	seq	number	primary key,
	projectName	varchar2(50)	NOT NULL,
	projectEx	varchar2(1000)	NULL,
	startDate	date	DEFAULT sysdate	NOT NULL,
	target	date	DEFAULT sysdate	NOT NULL,
	priority	number	DEFAULT 3	NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL
);

create sequence seqMemberTeam;
-- drop sequence seqMemberTeam;
CREATE TABLE memberTeam (
	seq	number	primary key,
	member_seq	number	NOT NULL,
	team_seq	number	NOT NULL,
	position	number	DEFAULT 2	NOT NULL,
    constraint fk_memberTeam_member foreign key(member_seq) references member(seq),
    constraint fk_memberTeam_team foreign key(team_seq) references team(seq)
);

create sequence seqTeamProject;
-- drop sequence seqTseamProject;
CREATE TABLE teamProject (
	seq	number	primary key,
	team_seq	number	NOT NULL,
	project_seq	number	NOT NULL,
    constraint fk_teamProject_project foreign key(project_seq) references project(seq)
);

create sequence seqCalendar;
-- drop sequence seqCalendar;
CREATE TABLE calendar (
	seq	number	primary key,
	teamProject_seq	number	NOT NULL,
	startDate	date	DEFAULT sysdate	NOT NULL,
	target	date	NULL,
	priority	number	NULL,
	schedule	varchar2(100)	NOT NULL,
    constraint fk_calendar_teamProject foreign key(teamProject_seq) references teamProject(seq)
);

-- 챗봇 -----
create sequence seqChatbot;
-- drop sequence seqChatbot;
CREATE TABLE chatbot (
	seq	number	primary key,
	member_seq	number	NOT NULL,
	memberMsg	varchar2(2000)	NOT NULL,
	botMsg	varchar2(2000)	NOT NULL,
	chatDate	date	DEFAULT sysdate	NOT NULL,
    constraint fk_chatbot_member foreign key(member_seq) references member(seq)
);

-- 코드 편집기 -----
create sequence seqTheme;
-- drop sequence seqTheme;
CREATE TABLE theme (
	seq	number	NOT NULL,
	theme	number(1)	DEFAULT 0	NOT NULL,
	member_seq	number	NOT NULL,
    constraint fk_theme_member foreign key(member_seq) references member(seq)
);

create sequence seqStyleType;
-- drop sequence seqStyleType;
CREATE TABLE styleType (
	seq	number	primary key,
	category	varchar2(50)	NOT NULL
);

create sequence seqStyleSetting;
-- drop sequence seqStyleSetting;
CREATE TABLE styleSetting (
	seq	number	primary key,
	value	varchar2(100)	NOT NULL,
	member_seq	number	NOT NULL,
	styleType_seq	number	NOT NULL,
    constraint fk_styleSetting_member foreign key(member_seq) references member(seq),
    constraint fk_styleSetting_styleType foreign key(styleType_seq) references styleType(seq)
);

create sequence seqBasicTemplate;
-- drop sequence seqBasicTemplate;
CREATE TABLE basicTemplate (
	seq	number	NOT NULL,
	keyword	varchar2(100)	NOT NULL,
	code	varchar2(2000)	NOT NULL
);

create sequence seqTemplate;
-- drop sequence seqTemplate;
CREATE TABLE template (
	seq	number	primary key,
	keyword	varchar2(100)	NOT NULL,
	code	varchar2(2000)	NOT NULL,
	member_seq	number	NOT NULL,
    constraint fk_template_member foreign key(member_seq) references member(seq)
);

create sequence seqVersionInfo;
-- drop sequence seqVersionInfo;
CREATE TABLE versionInfo (
	seq	number	primary key,
	regdate	date	DEFAULT sysdate	NOT NULL,
	message	varchar2(300)	NULL,
	project_seq	number	NOT NULL,
	member_seq	number	NOT NULL,
    constraint fk_versionInfo_project foreign key(project_seq) references project(seq),
    constraint fk_versionInfo_member foreign key(member_seq) references member(seq)
);

create sequence seqFileType;
-- drop sequence seqFileType;
CREATE TABLE fileType (
	seq	number	primary key,
	fileType	varchar2(100)	NOT NULL
);

create sequence seqVersionFile;
-- drop sequence seqVersionFile;
CREATE TABLE versionFile (
	seq	number	primary key,
	name	varchar2(600)	NOT NULL,
	code	varchar2(4000)	NULL,
	versionInfo_seq	number	NOT NULL,
	fileType_seq	number	NOT NULL,
	parent_seq	number	NULL,
    constraint fk_versionFile_versionInfo foreign key(versionInfo_seq) references versionInfo(seq),
    constraint fk_versionFile_fileType foreign key(fileType_seq) references fileType(seq),
    constraint fk_versionFile_parent foreign key(parent_seq) references versionFile(seq)
);


create sequence seqBasicFile;
-- drop sequence seqBasicFile;
CREATE TABLE basicFile (
	seq	number	primary key,
	name	varchar2(600)	NOT NULL,
	code	varchar2(4000)	NULL,
	fileType_seq	number	NOT NULL,
	parent_seq	number	NULL,
    constraint fk_basicFile_fileType foreign key(fileType_seq) references fileType(seq),
    constraint fk_basicFile_parent foreign key(parent_seq) references basicFile(seq)
);

-- 채팅 -----
create sequence seqServerList;
-- drop sequence seqServerList;
CREATE TABLE serverList (
	seq	number	primary key,
	serverName	varchar2(100)	NOT NULL,
	projectServerCheck	varchar2(1)	DEFAULT 'N'	NOT NULL
);

create sequence seqTextChannel;
-- drop sequence seqTextChannel;
CREATE TABLE textChannel (
	seq	number	primary key,
	textChannelName	varchar2(100)	DEFAULT '채팅채널1번' 	NULL,
	serverList_seq	number	NOT NULL,
    constraint fk_textchannel_serverList foreign key(serverList_seq) references serverList(seq)
);

create sequence seqTextContent;
-- drop sequence seqTextContent;
CREATE TABLE textContent (
	seq	number	primary key,
	content	varchar2(4000)	NOT NULL,
	messageSentTime	date	NOT NULL,
	textChannel_seq	number	NOT NULL,
    constraint fk_textContent_textChannel foreign key(textChannel_seq) references textChannel(seq)
);

create sequence seqMemberServer;
-- drop sequence seqMemberServer;
CREATE TABLE memberServer (
	seq	number	primary key,
	serverList_seq	number	NOT NULL,
	member_seq	number	NOT NULL,
    constraint fk_memberServer_serverList foreign key(serverList_seq) references serverList(seq),
    constraint fk_memberServer_member foreign key(member_seq) references member(seq)
);

create sequence seqVoiceChannel;
-- drop sequence seqVoiceChannel;
CREATE TABLE voiceChannel (
	seq	number	primary key,
	voiceChannelName	varchar(100)	DEFAULT '음성채널1번' 	NULL,
	serverList_seq	number	NOT NULL,
    constraint fk_voiceChannel_serverList foreign key(serverList_seq) references serverList(seq)
);

create sequence seqVoiceChannelSetting;
-- drop sequence seqVoiceChannelSetting;
CREATE TABLE voiceChannelSetting (
	seq	number	primary key,
	audioDevice	varchar2(1000)	DEFAULT '시스템 기본장치'	NULL,
	audioVolume	number	DEFAULT 50	NULL,
	recordingDevice	varchar2(1000)	DEFAULT '시스템 기본장치'	NULL,
	recordingVolume	number	DEFAULT 50	NULL,
	voiceChannel_seq	number	NOT NULL,
    constraint fk_voiceSetting_voiceChannel foreign key(voiceChannel_seq) references voiceChannel(seq)
);

rollback;
commit;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

insert into member (seq, id, pw, nick, regdate, ing, color, oAuthType) values (seqMember.nextVal, 'test@google.com', 'a1234567!', 'test', default, default, default, default);
insert into team(seq, teamname, teamex, teamtype, regdate) values(seqTeam.nextVal, '스프링팀', '학원 팀', 2, default);
insert into project(seq, projectname, projectex, startdate, target, priority, regdate) values(seqProject.nextVal, '스프링프로젝트', '스프링프로젝트입니다.', default, default, default, default);
insert into teamProject(seq, team_seq, project_seq) values(seqTeamProject.nextVal, 1, 1);
insert into calendar(seq, teamProject_seq, startdate, target, priority, schedule) values(seqCalendar.nextVal, 1, default, default, default, 1);
insert into memberTeam(seq, member_seq, team_seq, position) values(seqMemberTeam.nextVal, 2, 1, default);

select * From member;
select * From team;
select * From project;
select * From teamProject;
select * From calendar;
select * from memberTeam;
select * from vwMemberProject;

insert into member (seq, id, pw, nick, regdate, ing, color, oAuthType) 
		values (seqMember.nextVal, #{id}, #{pw}, #{nick}, default, default,  
    			(select case when max((select max(color) from member where seq = (select max(seq) from member))) >= 1 then 1 
    							else max((select max(color) from member where seq = (select max(seq) from member)))+1 end from member), default);

select case when max(1) >= 1 then 1 else max(1+1 end from member);

insert into fileType (seq, fileType) values (seqFileType.nextVal, 'Project');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'Folder');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'Package');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'Class');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'Interface');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'TextFile');
insert into fileType (seq, fileType) values (seqFileType.nextVal, 'File');

INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'TestProject', null, 1, null);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'src', null, 2, 1);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'com.test.main', null, 3, 2);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'Test.java', 'public class Test {\n    public static void main(String[] args) {\n        System.out.println("test");\n    }\n}', 4, 3);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'Inter.java', 'public interface Inter {\n\n}', 5, 3);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'txt.file', null, 6, 3);
INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq) VALUES (seqBasicFile.nextVal, 'file', null, 7, 3);
ALTER TABLE versionFile MODIFY code VARCHAR2(4000);

insert into versionInfo (seq, regdate, message, project_seq, member_seq) values (seqVersionInfo.nextVal, sysdate, 'test massge', 1, 1);

insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'TestProject', null,  1, 1, null);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'src', null,  1, 2, 1);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'com.test.main', null,  1, 3, 2);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'Test.java', 'public class Test {\n    public static void main(String[] args) {\n        System.out.println("test");\n    }\n}',  1, 4, 3);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'Inter.java', 'public interface Inter {\n\n}',  1, 5, 3);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'txt.file', null,  1, 6, 3);
insert into versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq) values (seqVersionFile.nextVal, 'file', null,  1, 7, 3);

INSERT INTO theme (seq, theme, member_seq) VALUES (seqTheme.nextVal, DEFAULT, 1);

INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'fontSize');
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'fontFamily');
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'editor.background');
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'editor.foreground');  
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'java.comment');
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'java.keyword');
INSERT INTO styleType (seq, category) VALUES (seqStyleType.nextVal, 'java.String');

INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '14', 1, 1); 
INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, 'D2Coding', 1, 1); 

INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#1E1E1E', 3, 1); 
INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#D4D4D4', 4, 1);   
INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#608B4E', 5, 1); 
INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#569CD6', 6, 1); 
INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#CE9178', 7, 1); 

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'sysout', 'System.out.println(${1});${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'trycatch', 'try {\n    ${1}\n} catch (${2:Exception} ${3:e}) {\n    ${4}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'tryfinally', 'try {\n    ${1}\n} finally {\n    ${2}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'main', 'public static void main(String[] args) {\n    ${0}\n}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'if', 'if (${1:condition}) {\n    ${2}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'else', 'else {\n    ${1}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'catch', 'catch (${1:Exception} ${2:e}) {\n    ${3}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'finally', 'finally {\n    ${1}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'switch', 'switch (${1:key}) {\n    case ${2:value}:\n        ${0}\n        break;\n    default:\n        break;\n}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'while', 'while (${1:condition}) {\n    ${2}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'dowhile', 'do {\n    ${0}\n} while (${1:condition});');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'for', 'for (int ${1:index} = 0; ${1:index} < ${2:array}.length; ${1:index}++) {\n    ${3}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'foreach', 'for (${1:Type} ${2:item} : ${3:collection}) {\n    ${0}\n}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'syserr', 'System.err.println(${1});${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'ifelse', 'if (${1:condition}) {\n    ${2}\n} else {\n    ${2}\n}${0}');

INSERT INTO basicTemplate (seq, keyword, code) 
VALUES (seqBasicTemplate.nextVal, 'ifelseif', 'if (${1:condition}) {\n    ${2}\n} else if (${3:condition}) {\n    ${4}\n} else {\n    ${5}\n}${0}');


INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'sysout', 'System.out.println(${1});${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'trycatch', 'try {\n    ${1}\n} catch (${2:Exception} ${3:e}) {\n    ${4}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'tryfinally', 'try {\n    ${1}\n} finally {\n    ${2}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'main', 'public static void main(String[] args) {\n    ${0}\n}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'if', 'if (${1:condition}) {\n    ${2}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'else', 'else {\n    ${1}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'catch', 'catch (${1:Exception} ${2:e}) {\n    ${3}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'finally', 'finally {\n    ${1}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'switch', 'switch (${1:key}) {\n    case ${2:value}:\n        ${0}\n        break;\n    default:\n        break;\n}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'while', 'while (${1:condition}) {\n    ${2}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'dowhile', 'do {\n    ${0}\n} while (${1:condition});');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'for', 'for (int ${1:index} = 0; ${1:index} < ${2:array}.length; ${1:index}++) {\n    ${3}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'foreach', 'for (${1:Type} ${2:item} : ${3:collection}) {\n    ${0}\n}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'syserr', 'System.err.println(${1});${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'ifelse', 'if (${1:condition}) {\n    ${2}\n} else {\n    ${2}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'ifelseif', 'if (${1:condition}) {\n    ${2}\n} else if (${3:condition}) {\n    ${4}\n} else {\n    ${5}\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'class', 'public class ${1:ClassName} {\n\n    private ${2:Type} ${3:field};\n\n    public ${1:ClassName}(${2:Type} ${3:field}) {\n        this.${3:field} = ${3:field};\n    }\n\n    public ${2:Type} get${3:Field}() {\n        return ${3:field};\n    }\n\n    public void set${3:Field}(${2:Type} ${3:field}) {\n        this.${3:field} = ${3:field};\n    }\n\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'unittest', '@Test\npublic void ${1:testMethod}() {\n    // given\n    ${2:Setup code}\n\n    // when\n    ${3:Execution code}\n\n    // then\n    assert${4:Condition}(${5:Expected}, ${6:Actual});\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'gettersetter', 'public ${1:Type} get${2:Field}() {\n    return ${3:field};\n}\n\npublic void set${2:Field}(${1:Type} ${3:field}) {\n    this.${3:field} = ${3:field};\n}${0}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'lambda', '${1:collection}.stream()\n    .filter(${2:item} -> ${3:condition})\n    .forEach(${2:item} -> {\n        ${0} \n    });');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'switchenum', 'switch (${1:enumVariable}) {\n    case ${2:EnumValue1}:\n        ${0} \n        break;\n    case ${3:EnumValue2}:\n        \n        break;\n    default:\n        throw new IllegalArgumentException("Unexpected value: " + ${1:enumVariable});\n}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'trywithresources', 'try (${1:ResourceType} ${2:resource} = new ${1:ResourceType}()) {\n    ${0} \n} catch (${3:ExceptionType} ${4:e}) {\n    ${5} \n}');

INSERT INTO template (seq, member_seq, keyword, code) 
VALUES (seqTemplate.nextVal, 1, 'jsonparse', 'ObjectMapper objectMapper = new ObjectMapper();\n${1:Type} ${2:variable} = objectMapper.readValue(${3:jsonData}, ${1:Type}.class);${0}');

CREATE OR REPLACE PROCEDURE insert_default_settings(p_member_seq NUMBER) AS
BEGIN

    INSERT INTO theme (seq, theme, member_seq) VALUES (seqTheme.nextVal, 0, p_member_seq);
    
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '14', 1, p_member_seq);
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, 'Consolas', 2, p_member_seq);
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#1E1E1E', 3, p_member_seq); 
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#D4D4D4', 4, p_member_seq);   
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#608B4E', 5, p_member_seq); 
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#569CD6', 6, p_member_seq); 
    INSERT INTO styleSetting (seq, value, styleType_seq, member_seq) VALUES (seqStyleSetting.nextVal, '#CE9178', 7, p_member_seq); 
    
    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'sysout', 'System.out.println(${1});${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'trycatch', 'try {\n    ${1}\n} catch (${2:Exception} ${3:e}) {\n    ${4}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'tryfinally', 'try {\n    ${1}\n} finally {\n    ${2}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'main', 'public static void main(String[] args) {\n    ${0}\n}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'if', 'if (${1:condition}) {\n    ${2}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'else', 'else {\n    ${1}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'catch', 'catch (${1:Exception} ${2:e}) {\n    ${3}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'finally', 'finally {\n    ${1}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'switch', 'switch (${1:key}) {\n    case ${2:value}:\n        ${0}\n        break;\n    default:\n        break;\n}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'while', 'while (${1:condition}) {\n    ${2}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'dowhile', 'do {\n    ${0}\n} while (${1:condition});');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'for', 'for (int ${1:index} = 0; ${1:index} < ${2:array}.length; ${1:index}++) {\n    ${3}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'foreach', 'for (${1:Type} ${2:item} : ${3:collection}) {\n    ${0}\n}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'syserr', 'System.err.println(${1});${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'ifelse', 'if (${1:condition}) {\n    ${2}\n} else {\n    ${2}\n}${0}');    
    INSERT INTO template (seq, member_seq, keyword, code) VALUES (seqTemplate.nextVal, p_member_seq, 'ifelseif', 'if (${1:condition}) {\n    ${2}\n} else if (${3:condition}) {\n    ${4}\n} else {\n    ${5}\n}${0}');
    
    
END;
/

- 인서트 예시(회원 시퀀스)
BEGIN
    insert_default_settings(1); -- 회원 1에 대해 기본 설정 인서트
END;
/

CREATE OR REPLACE PROCEDURE switchTheme(
    theme IN NUMBER,
    member_seq IN NUMBER
)
AS
BEGIN
    IF theme = 1 THEN
        -- 전환: 다크 모드에서 라이트 모드
        UPDATE styleSetting SET value = '#FFFFFF' WHERE styleType_seq = 3 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#000000' WHERE styleType_seq = 4 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#3A7F25' WHERE styleType_seq = 5 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#001EF5' WHERE styleType_seq = 6 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#96261F' WHERE styleType_seq = 7 AND member_seq = member_seq;
    ELSIF theme = 0 THEN
        -- 전환: 라이트 모드에서 다크 모드
        UPDATE styleSetting SET value = '#1E1E1E' WHERE styleType_seq = 3 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#D4D4D4' WHERE styleType_seq = 4 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#608B4E' WHERE styleType_seq = 5 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#569CD6' WHERE styleType_seq = 6 AND member_seq = member_seq;
        UPDATE styleSetting SET value = '#CE9178' WHERE styleType_seq = 7 AND member_seq = member_seq;
    END IF;
END switchTheme;
/


- 인서트 예시 
BEGIN
    switchTheme(0, 1); -- 회원 1에 대해 라이트 모드에서 다크 모드로 전환
END;
/

CREATE OR REPLACE PROCEDURE CreateProjectStructure (
    p_project_name VARCHAR2
) AS
    v_project_seq NUMBER;
    v_src_seq NUMBER;
    v_package_seq NUMBER;
BEGIN
    -- Project 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, p_project_name, NULL, 
           (SELECT seq FROM fileType WHERE fileType = 'Project'), NULL)
    RETURNING seq INTO v_project_seq;

    -- src 폴더 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'src', NULL, 
           (SELECT seq FROM fileType WHERE fileType = 'Folder'), v_project_seq)
    RETURNING seq INTO v_src_seq;

    -- package 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'com.test.main', NULL, 
           (SELECT seq FROM fileType WHERE fileType = 'Package'), v_src_seq)
    RETURNING seq INTO v_package_seq;

    -- 기본 Class 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'Test.java', 
           'public class Test {\n    public static void main(String[] args) {\n        System.out.println("test");\n    }\n}', 
           (SELECT seq FROM fileType WHERE fileType = 'Class'), v_package_seq);

    -- 기본 Interface 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'Inter.java', 
           'public interface Inter {\n}', 
           (SELECT seq FROM fileType WHERE fileType = 'Interface'), v_package_seq);

    -- 기본 TextFile 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'txt.file', NULL, 
           (SELECT seq FROM fileType WHERE fileType = 'TextFile'), v_package_seq);

    -- 기본 File 생성
    INSERT INTO basicFile (seq, name, code, fileType_seq, parent_seq)
    VALUES (seqBasicFile.NEXTVAL, 'file', NULL, 
           (SELECT seq FROM fileType WHERE fileType = 'File'), v_package_seq);

    COMMIT;
END;
/

CREATE OR REPLACE PROCEDURE proc_versionInfo (
    p_project_seq IN NUMBER,
    p_message IN VARCHAR2,
    p_project_name IN VARCHAR2
)
IS
    v_version_seq NUMBER;
BEGIN
    -- Step 1: versionInfo에 새 버전 정보 추가
    INSERT INTO versionInfo (seq, regdate, message, project_seq, member_seq)
    VALUES (seqVersionInfo.NEXTVAL, SYSDATE, p_message, p_project_seq, 1)
    RETURNING seq INTO v_version_seq;

    -- Step 2: versionFile에 기본 파일 구조 추가 (사용자 입력 프로젝트 이름 사용)
    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, p_project_name, NULL, v_version_seq, 1, NULL);

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, 'src', NULL, v_version_seq, 2, (SELECT seq FROM versionFile WHERE name = p_project_name AND versionInfo_seq = v_version_seq));

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, p_project_name || '.main', NULL, v_version_seq, 3, (SELECT seq FROM versionFile WHERE name = 'src' AND versionInfo_seq = v_version_seq));

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, p_project_name || '.java', 'public class ' || p_project_name || ' {\n    public static void main(String[] args) {\n        System.out.println("test");\n    }\n}', v_version_seq, 4, (SELECT seq FROM versionFile WHERE name = p_project_name || '.main' AND versionInfo_seq = v_version_seq));

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, 'Inter.java', 'public interface Inter {\n\n}', v_version_seq, 5, (SELECT seq FROM versionFile WHERE name = p_project_name || '.main' AND versionInfo_seq = v_version_seq));

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, 'txt.file', NULL, v_version_seq, 6, (SELECT seq FROM versionFile WHERE name = p_project_name || '.main' AND versionInfo_seq = v_version_seq));

    INSERT INTO versionFile (seq, name, code, versionInfo_seq, fileType_seq, parent_seq)
    VALUES (seqVersionFile.NEXTVAL, 'file', NULL, v_version_seq, 7, (SELECT seq FROM versionFile WHERE name = p_project_name || '.main' AND versionInfo_seq = v_version_seq));

    COMMIT;
END;
/

insert into chatbot values (seqChatbot.nextval,1,'안녕','안녕하세요. 무엇을 도와드릴까요?',sysdate);
insert into memberServer values (seqMemberServer.nextval,1,1);
insert into serverList values (seqServerList.nextval,’Spring Project’,’Y’);
insert into voiceChannel values (seqVoiceChannel.nextval,’음성채널1번’,1);
insert into voiceChannelSetting values (seqVoiceChannelSetting.nextval,’시스템기본장치’,50,’시스템기본장치,50,1);
insert into textContent values (sequence seqTextContent.nextval,’채팅내용입니다’,sysdate,1);


commit;
