package com.test.chat;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DBTest {
	
//	@Autowired
//	private ChatMapper mapper;
//	
//	@Test
//	public void testDB() {
//		assertNotNull(mapper);
//	}
}
