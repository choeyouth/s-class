package com.test.editor.model;

import lombok.Data;

@Data
public class VoiceChannelDTO {

	private String seq;
	private String voiceChannelName;
	private String serverList_seq;
	
}
