package com.test.editor.model;

import lombok.Data;

@Data
public class CalendarDTO {

	private String seq;
	private String teamProject_seq;
	private String startDate;
	private String target;
	private String priority;
	private String schedule;
	
}
