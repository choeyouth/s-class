package com.test.editor.model;

import lombok.Data;

@Data
public class TeamDTO {

	private String seq;
	private String teamName;
	private String teamEx;
	private String teamType;
	private String regdate;
	private String teamSeq;
	
}
