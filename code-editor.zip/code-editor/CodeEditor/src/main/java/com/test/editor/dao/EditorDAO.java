package com.test.editor.dao;

public class EditorDAO {

}
