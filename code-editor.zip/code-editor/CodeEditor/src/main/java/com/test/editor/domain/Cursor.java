package com.test.editor.domain;

import lombok.Data;

@Data
public class Cursor {

}
