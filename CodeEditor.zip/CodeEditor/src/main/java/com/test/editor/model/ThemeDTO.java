package com.test.editor.model;

import lombok.Data;

@Data
public class ThemeDTO {

	private String seq;
	private String theme;
	private String member_seq;
	
}
