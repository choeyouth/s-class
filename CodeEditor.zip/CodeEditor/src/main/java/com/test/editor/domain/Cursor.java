package com.test.editor.domain;

public class Cursor {

}
