package com.test.editor.model;

import lombok.Data;

@Data
public class StyleSettingDTO {

	private String seq;
	private String value;
	private String styleType_seq;
	private String member_seq;
	private StyleTypeDTO styleType;

}
