package com.test.editor.model;

import lombok.Data;

@Data
public class TextChannelDTO {

	private String seq;
	private String content;
	private String messageSentTime;
	private String textChannel_seq;
	
}
