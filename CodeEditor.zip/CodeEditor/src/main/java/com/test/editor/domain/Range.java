package com.test.editor.domain;

public class Range {
	
	private int endColumn;
	private int endLineNumber;
	private int startColumn;
	private int startLineNumber;
	
}
