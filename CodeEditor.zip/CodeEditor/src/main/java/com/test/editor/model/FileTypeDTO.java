package com.test.editor.model;

import lombok.Data;

@Data
public class FileTypeDTO {

	private String seq;
	private String fileType;
	
}
