//package com.test.editor.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//
//@Controller
//public class BasicFileController {
//
//	@Autowired
//	private BasicFileService basicFileService;
//	
//}
