package com.test.editor.model;

import lombok.Data;

@Data
public class StyleTypeDTO {

	private String seq;
	private String category;
	
}
