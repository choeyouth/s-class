package com.test.editor.model;

import lombok.Data;

@Data
public class MemberTeamDTO {

	private String seq;
	private String team_seq;
	private String project_seq;
	
}
