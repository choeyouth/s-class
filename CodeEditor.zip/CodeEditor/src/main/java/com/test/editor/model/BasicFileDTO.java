package com.test.editor.model;

import lombok.Data;

@Data
public class BasicFileDTO {

	private String seq;
	private String name;
	private String code;
	private String fileType_seq;
	private String parent_seq;
	
}
