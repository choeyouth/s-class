package com.test.editor.model;

import lombok.Data;

@Data
public class VersionInfoDTO {

	private Integer seq;
	private String regdate;
	private String message;
	private Integer project_seq;
	private Integer member_seq;
	
	
	
}
