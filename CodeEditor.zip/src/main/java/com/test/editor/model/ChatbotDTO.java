package com.test.editor.model;

import lombok.Data;

@Data
public class ChatbotDTO {

	private String seq;
	private String member_seq;
	private String memberMsg;
	private String botMsg;
	private String chatDate;
	
}
