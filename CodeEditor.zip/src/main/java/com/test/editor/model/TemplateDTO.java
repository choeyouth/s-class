package com.test.editor.model;

import lombok.Data;

@Data
public class TemplateDTO {

	private String seq;
	private String keyword;
	private String code;
	private String member_seq;
	
}
