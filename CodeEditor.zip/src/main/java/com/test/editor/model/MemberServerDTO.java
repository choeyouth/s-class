package com.test.editor.model;

import lombok.Data;

@Data
public class MemberServerDTO {

	private String seq;
	private String serverList_seq;
	private String member_seq;
	
}
