//package com.test.editor.service;
//
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.test.editor.dao.FileTypeDAO;
//
//@Service
//public class FileTypeService {
//
//    @Autowired
//    private FileTypeDAO fileTypeDao;
//
//    public List<Map<String, Object>> getAllFileTypes() {
//        // fileTypeDao를 사용해 모든 파일 유형을 조회
//        return fileTypeDao.getAllFileTypes();
//    }
//}
