package com.test.editor.mapper;

public interface EditorMapper {

}
