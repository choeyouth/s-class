package com.rebook.mybook.model;

public class BookMarkDTO {

}
