package com.rebook.discussion.model;

public class DiscussionReplyDTO {

}
