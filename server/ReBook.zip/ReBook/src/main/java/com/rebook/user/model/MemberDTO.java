package com.rebook.user.model;

public class MemberDTO {

}
