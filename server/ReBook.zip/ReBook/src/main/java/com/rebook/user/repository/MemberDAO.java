package com.rebook.user.repository;

public class MemberDAO {

}
