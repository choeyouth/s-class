package com.rebook.mybook.repository;

public class MarkDAO {

}
