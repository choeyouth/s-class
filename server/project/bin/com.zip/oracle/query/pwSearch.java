package com.oracle.query;

import java.sql.SQLException;

public class pwSearch {

    public static void main(String[] args) throws SQLException {
    	
    	
    	
    }
	
}
