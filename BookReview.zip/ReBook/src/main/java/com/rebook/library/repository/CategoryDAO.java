package com.rebook.library.repository;

public class CategoryDAO {

}
