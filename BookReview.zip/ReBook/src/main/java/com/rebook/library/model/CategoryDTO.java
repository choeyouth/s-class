package com.rebook.library.model;

public class CategoryDTO {

}
