package com.rebook.library.repository;

public class LibraryDAO {

}
