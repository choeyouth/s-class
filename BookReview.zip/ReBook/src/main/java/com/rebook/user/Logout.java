package com.rebook.user;

public class Logout {

}
