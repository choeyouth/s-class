package com.rebook.quote.repository;

public class QuoteListDAO {

}
