package com.rebook.quote.model;

public class QuoteListDTO {

}
