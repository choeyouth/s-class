package com.rebook.word.model;

public class WordDTO {

}
