package com.rebook.word.repository;

public class WordDAO {

}
