package com.rebook.library.model;

import lombok.Data;

@Data
public class CategoryDTO {
	private String seq;
	private String category;
}
