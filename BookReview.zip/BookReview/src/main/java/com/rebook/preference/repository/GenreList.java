package com.rebook.preference.repository;

public class GenreList {

}
