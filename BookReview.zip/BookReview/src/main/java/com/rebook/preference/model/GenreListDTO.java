package com.rebook.preference.model;

public class GenreListDTO {

}
