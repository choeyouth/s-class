package com.rebook.mybook.repository;

public class ReviewDAO {

}
