package com.rebook.mybook.repository;

public class RankDAO {

}
