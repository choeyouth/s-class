package com.rebook.mybook.model;

import lombok.Data;

@Data
public class MarkDTO {
	private String membername;
	private String score;
	private String bookname;
	private String cover;
	
}
