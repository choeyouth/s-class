package com.rebook.mybook.model;

import lombok.Data;

@Data
public class MarkDTO {
	
}
