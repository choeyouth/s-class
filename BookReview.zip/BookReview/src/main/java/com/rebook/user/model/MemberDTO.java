package com.rebook.user.model;

import lombok.Data;

@Data
public class MemberDTO {
	
	private String seq;
	private String id;
	private String password;
	private String ing;
	private String lv;

}
