package com.rebook.discussion.repository;

public class ReplyDAO {

}
