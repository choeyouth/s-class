package com.rebook.discussion.repository;

public class BoardDAO {

}
