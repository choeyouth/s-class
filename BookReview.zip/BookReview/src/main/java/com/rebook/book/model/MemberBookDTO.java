package com.rebook.book.model;

public class MemberBookDTO {

}
