package com.rebook.book.model;

import lombok.Data;

@Data
public class OtherInfoDTO {

	private String link;
	private String publisher;
	private String pubDate;
	
}
