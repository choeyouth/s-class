package com.rebook.book.repository;

public class MemberBookDAO {

}
