package com.rebook.book.model;

import lombok.Data;

@Data
public class WishBookDTO {
	
	private String seq;
	private String member_seq;
	private String book_seq; 
	private String memberName;

}
