package com.rebook.discussion;

public class BoardList {

}
