package com.rebook.book.repository;

public class BookDAO { 
	
}
