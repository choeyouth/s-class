package com.rebook.user.repository;


public class MemberInfoDAO {


	
}
