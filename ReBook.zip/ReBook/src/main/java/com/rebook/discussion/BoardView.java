package com.rebook.discussion;

public class BoardView {

}
